# APEX PURE — Visual Asset Pack

## Project identity
- Brand: APEX PURE
- Product: Creatine Monohydrate Powder
- Market: International
- Art direction: HYBRID SIGNATURE — cinematic luxury + performance + restrained futuristic details
- Palette: Obsidian `#0B0D10`, Carbon `#161A20`, Gold `#EAB308`, Amber `#F59E0B`, White `#FFFFFF`
- Tagline direction: PUSH BEYOND LIMITS.

## Files

### 01_PRODUCT_HERO/apex-pure-hero-product.png
Primary generated hero visual. It depicts a matte-black tub with gold accents and the APEX PURE name. Use as the main visual reference for the landing-page hero and product presentation. It is a concept render, not a photograph of manufactured packaging.

### 02_VISUAL_MOODBOARDS/
Three generated moodboards for lighting, composition, gym atmosphere, powder/scoop scenes, campaign art direction, and supporting visual ideas. These are mood references only. Do not reproduce small label copy, quantities, serving counts, net weight, certifications, health claims, or numerical claims from these collages. AI-generated lettering and product details may be inaccurate.

### 03_ORIGINAL_REFERENCES/
- `original-packaging-reference-capsules.jpg`: supplied reference for the bottle silhouette, lid, black label, and gold/yellow visual treatment only. It is a capsule product from another brand. Never copy its brand name, capsule wording, dosage, capsule count, serving count, or certification claims.
- `original-logo-reference-placeholder.jpg`: supplied geometric logo inspiration. The text in the source is placeholder text; do not use “LOREM IPSUM” or the original slogan. Recreate a clean APEX PURE logo from the geometric mark only.

## Critical product-data rules
The project brief identifies the product as powder, but verified commercial product facts have not been supplied. Therefore do not invent or display:
- net weight
- serving size or servings per container
- grams per serving
- price or bundle prices
- ingredients beyond the confirmed product identity
- laboratory testing, certifications, purity verification, or third-party testing
- customer reviews or testimonials

Use clearly marked editable placeholders until the owner supplies verified details. Do not use the generated moodboards as a source of factual product data.

## Instructions for the website-building AI
1. Treat the single hero render as the primary visual reference for the product's intended APEX PURE appearance.
2. Treat moodboards only as references for lighting, atmosphere, composition, and visual storytelling.
3. Treat the original packaging photo only as a shape/material reference; the final product is a powder tub, not capsules.
4. Do not reproduce any other brand name or the placeholder logo text.
5. Keep the product name exactly: `APEX PURE CREATINE MONOHYDRATE POWDER`.
6. Use the approved black-and-gold palette and premium editorial typography.
7. Build a distinctive responsive landing page; do not imitate a generic supplement template.
8. Keep the supplied assets in the project and reference them using relative paths. Do not replace them with unrelated stock imagery.

## Suggested asset usage
- Hero: `01_PRODUCT_HERO/apex-pure-hero-product.png`
- Brand atmosphere and visual direction: `02_VISUAL_MOODBOARDS/`
- Bottle silhouette and geometric logo inspiration: `03_ORIGINAL_REFERENCES/`
